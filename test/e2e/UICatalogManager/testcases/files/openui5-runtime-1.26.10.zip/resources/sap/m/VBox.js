/*!
 * SAP UI development toolkit for HTML5 (SAPUI5/OpenUI5)
 * (c) Copyright 2009-2015 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(['jquery.sap.global','./FlexBox','./library'],function(q,F,l){"use strict";var V=F.extend("sap.m.VBox",{metadata:{library:"sap.m"}});return V},true);
